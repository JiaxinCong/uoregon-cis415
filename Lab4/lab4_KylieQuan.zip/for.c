#include <stdio.h>

int main() {
	int i;
	printf("For loop: starting\n");
	for (i=0; i<100; i++) {}

	printf("For loop: I am done\n");
}
